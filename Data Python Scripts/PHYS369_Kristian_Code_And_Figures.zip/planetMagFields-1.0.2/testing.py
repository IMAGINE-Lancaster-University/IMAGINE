from planetmagfields import *
p = planet(name='ganymede',datDir='planetmagfields/data/')
p.plot(r=3.0, proj='Mollweide')

# For the "name" argument use "jupiter" or "ganymede".